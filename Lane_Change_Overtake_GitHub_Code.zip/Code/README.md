# Code – Lane Change & Overtake Assistance System

This folder contains the Arduino/Embedded C implementation prepared for the
LoRa-based Vehicle-to-Vehicle (V2V) Lane Change and Overtake Assistance System.

## Files

- `Vehicle_Transmitter.ino` – collects GPS and ultrasonic information and
  transmits vehicle data using LoRa.
- `Vehicle_Receiver.ino` – receives vehicle data through LoRa, evaluates the
  safety condition, and activates an LED/buzzer warning.

## Main functions

1. GPS collects vehicle location and speed.
2. Ultrasonic sensing provides nearby-vehicle distance.
3. The transmitter sends vehicle information through LoRa.
4. The receiver reads the LoRa packet.
5. Relative speed is calculated.
6. Distance is compared with the safety threshold.
7. LED and buzzer indicate an unsafe condition.

## Communication packet

The project report specifies the basic vehicle data format as:

`<ID, Speed, Latitude, Longitude, Direction>`

The code extends this packet with the measured distance:

`ID,Speed,Latitude,Longitude,Direction,Distance`

This allows the receiver to use the distance measurement in its safety logic.

## Required Arduino libraries

Install these libraries in Arduino IDE:

- LoRa by Sandeep Mistry
- TinyGPSPlus

## Hardware assumed by this code

- ESP32 development board
- SX1278/RFM95-compatible LoRa module
- NEO-6M GPS module
- HC-SR04 ultrasonic sensor
- LED
- Buzzer

## Important

The report does not specify the exact ESP32 GPIO pin connections or the exact
LoRa frequency used in the prototype. Therefore, the pin assignments and
`433E6` frequency in these files are example values and must be changed to
match the actual hardware used by the team.

Do not upload these sketches to hardware without checking the wiring and
radio-frequency configuration first.
